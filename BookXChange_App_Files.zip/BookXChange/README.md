# BookXChange mobile web app

This is a mobile-first, responsive prototype for the BookXChange campus book-sharing concept.

## Run it locally
1. Extract the ZIP file.
2. Open `index.html` in a browser.

## Publish it using GitHub Pages
1. Sign in to GitHub and create a new public repository named `BookXChange`.
2. Upload `index.html` to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under the build/deployment source, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then save.
6. After GitHub Pages finishes deploying, your app URL will be shown in the Pages settings. It will usually look like `https://YOUR-USERNAME.github.io/BookXChange/`.

## Included prototype features
- Login/register screens and demo mode
- Searchable, filterable sample book catalogue
- Book listing form
- Borrow/exchange requests
- Request approval/rejection in admin preview
- Transaction history
- Simulated NFC scan and return workflow
- Responsive mobile interface

## Important limitations
This is a front-end prototype. Authentication, college email verification, shared database, real notifications, and physical NFC reading are not connected. Demo changes are kept in the current page session and are not synced across devices. Do not use it to store sensitive data or represent the demo admin view as secure access.
